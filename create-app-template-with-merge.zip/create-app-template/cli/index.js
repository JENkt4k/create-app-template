#!/usr/bin/env node

const { Command } = require("commander");
const degit = require("degit");
const execa = require("execa");
const path = require("path");
const fs = require("fs-extra");
const templates = require("../templates.json");

const program = new Command();

program
  .name("create-app-template")
  .description("Scaffold a framework template with evolution")
  .requiredOption("-f, --framework <name>", "Framework to use")
  .option("-b, --branch <branch>", "Template evolution branch to use")
  .option("-i, --include <modules>", "Comma-separated modules to merge")
  .option("-d, --directory <dir>", "Target directory", ".");

program.parse(process.argv);
const options = program.opts();

async function main() {
  const fw = templates[options.framework];
  if (!fw) {
    console.error("Unknown framework: " + options.framework);
    process.exit(1);
  }

  const repo = fw.repo + (options.branch ? "#" + options.branch : "");
  const emitter = degit(repo, { cache: false, force: true });
  const outDir = path.resolve(process.cwd(), options.directory);

  console.log(`📦 Cloning ${repo} into ${outDir}`);
  await emitter.clone(outDir);

  if (fs.existsSync(path.join(outDir, "package.json"))) {
    console.log("📦 Installing dependencies...");
    await execa("npm", ["install"], { cwd: outDir, stdio: "inherit" });
  }

  // Handle --include modules
  if (options.include) {
    const modules = options.include.split(",");
    for (const mod of modules) {
      const modPath = path.resolve(__dirname, "../modules", mod);
      if (fs.existsSync(modPath)) {
        console.log(`🔧 Merging module: ${mod}`);
        await fs.copy(modPath, outDir, { overwrite: true });
      } else {
        console.warn(`⚠️ Module not found: ${mod}`);
      }
    }
  }

  console.log("✅ Done!");
}

main();
